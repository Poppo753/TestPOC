# Jethos — Software-Only Financial OS
## Storyboard del deck `Jethos_Software_Only_Refactor.pptx`

**Formato:** 16:9 (13,33" × 7,5") — 20 slide principali + 4 slide di appendice
**Principio narrativo:** *"Jethos compila e spiega; l'utente decide, autorizza ed esegue."*
**Codifica colore dei soggetti (costante su tutto il deck):**

| Soggetto | Colore | Uso |
|---|---|---|
| **User** | Teal `00A896` | possesso, chiavi, firma, decisione |
| **Jethos software** | Navy `13315C` | client, build/decode/preview/simulate, registry |
| **Provider / Protocol** | Steel `8FA6C4` | funzioni regolamentate e stato on-chain esterni |

**Badge:** `CURRENT FACT` (grigio) · `TARGET DECISION` (teal) · `EXTERNAL GATE` (ambra) · `SECURITY BLOCKER` (rosso)

**Nota di metodo:** i documenti di audit sul repository non erano leggibili nell'ambiente di generazione. Tutte le affermazioni fattuali riportate nel deck derivano dal brief; ogni elemento non dimostrato è rappresentato come gate, ipotesi o domanda. Vedi `Jethos_Software_Only_Refactor_Sources.md`.

---

## PARTE EXECUTIVE (slide 1–3, autonoma)

### Slide 1 — Cover
- **Obiettivo:** aprire con il posizionamento e i tre numeri che qualificano lo stato dell'analisi.
- **Titolo:** *Jethos — From Pooled DeFi Protocol to Software-Only Financial OS*
- **Messaggio principale:** un'esperienza finanziaria unificata, senza custodia e senza esecuzione controllata da Jethos.
- **Contenuto:** sottotitolo; tre chip di stato: *56 componenti classificati* · *0 ONCHAIN_REQUIRED per il V1* · *Audit: NOT_READY_FOR_IMPLEMENTATION*; riga di principio.
- **Visual:** slide dark navy full-bleed, wordmark, titolo su due righe, chip con bordo teal.
- **Speaker notes:** Questo deck non propone un restyling del prodotto: propone di spostare custodia ed esecuzione fuori da Jethos. Le prime tre slide sono un executive summary autonomo. NOT_READY_FOR_IMPLEMENTATION è lo stato dell'audit, non un giudizio sulla strategia.
- **Fonti:** brief §Accuratezza; §Struttura.

### Slide 2 — Visione
- **Obiettivo:** far capire l'ambizione UX senza generare l'aspettativa che Jethos diventi banca.
- **Titolo:** *Vogliamo l'esperienza di un home banking moderno, senza diventarne l'infrastruttura*
- **Messaggio principale:** un'unica interfaccia per sette domini finanziari; l'infrastruttura resta di provider e protocolli specializzati.
- **Contenuto:** tre punti di visione a sinistra; a destra griglia di 7 tile di servizio (wallet/Smart Account, identità/KYC, cash/IBAN, carte, investimenti, DeFi diretta, vista multi-chain) + tile di sintesi "un'unica interfaccia".
- **Visual:** due colonne, griglia 2×4 di card con token circolari.
- **Speaker notes:** L'utente percepisce completezza tipo Revolut. Dietro, ogni dominio è servito da un provider autorizzato o da un protocollo pubblico. Nessuna di queste funzioni viene replicata internamente.
- **Fonti:** brief §Obiettivo narrativo.

### Slide 3 — Trasformazione in una pagina
- **Obiettivo:** rendere la trasformazione comprensibile in 30 secondi.
- **Titolo:** *La trasformazione in una pagina: dalla custodia pooled al controllo dell'utente*
- **Messaggio principale:** cambiano architettura, controllo dei fondi, esecuzione e ruolo di Jethos; il risultato per l'utente passa da quota di un pool a posizioni intestate.
- **Contenuto:** confronto Today → Target su 5 righe: Architettura · Controllo dei fondi · Esecuzione · Ruolo Jethos · Risultato utente.
- **Visual:** due card affiancate (OGGI grigia, TARGET teal) con colonna di etichette e freccia centrale; legenda dei tre soggetti.
- **Speaker notes:** Oggi: contratti Jethos custodiscono asset, emettono LPT, muovono capitale via manager e plugin controllati dall'operatore. Target: Smart Account dell'utente, chiamate dirette ai protocolli, Jethos come software che compila e spiega.
- **Fonti:** brief §Struttura slide 3; §Accuratezza (pooled custody/LPT, direct protocol calls).

---

## PARTE DETTAGLIATA (slide 4–20)

### Slide 4 — Perché cambiare ora
- **Obiettivo:** motivare la tempistica con dati, non con opinione.
- **Titolo:** *Cambiare ora costa meno che consolidare un'architettura custodiale*
- **Messaggio principale:** l'analisi è già stata fatta, il debito è misurato e nessun componente V1 richiede on-chain: la finestra è adesso.
- **Contenuto:** 4 stat callout (56 componenti classificati · 0 ONCHAIN_REQUIRED V1 · 278 task checklist · 380 finding security) + 3 card di driver (superficie custodiale crescente, ogni nuova funzione moltiplica gli obblighi, il valore è nel client non nei contratti).
- **Visual:** riga superiore di 4 numeri grandi, riga inferiore di 3 card.
- **Speaker notes:** Il fatto che zero componenti richiedano on-chain per il V1 è il dato che rende la trasformazione praticabile senza riscrivere contratti. I 380 finding e i 278 task quantificano il lavoro, non lo bloccano.
- **Fonti:** brief §Accuratezza.

### Slide 5 — Architettura corrente
- **Obiettivo:** descrivere lo stato attuale in modo neutro e verificabile.
- **Titolo:** *Oggi il capitale vive nei contratti Jethos, non nei conti degli utenti*
- **Messaggio principale:** custodia pooled, quote LPT, movimentazione via manager e plugin controllati dall'operatore.
- **Contenuto:** flusso Utente → deposito → contratti Jethos (pooled custody) → manager/plugin → protocolli; ritorno LPT all'utente; nota architetturale: il Beacon attuale è un **service locator**, non un delegatecall proxy.
- **Visual:** diagramma a blocchi orizzontale con freccia di ritorno LPT; badge `CURRENT FACT`.
- **Speaker notes:** Precisione importante: il Beacon non è un proxy con delegatecall, è un service locator. Cambia il modello di rischio upgrade e va detto correttamente in ogni discussione tecnica.
- **Fonti:** brief §Accuratezza (Beacon, pooled custody, LPT); documenti di audit (da rileggere per conferma di dettaglio).

### Slide 6 — Limiti e rischi
- **Obiettivo:** spiegare perché l'architettura attuale non scala verso il perimetro Financial OS.
- **Titolo:** *Ogni funzione in più moltiplica superficie custodiale e obblighi regolamentari*
- **Messaggio principale:** i limiti sono strutturali, non di implementazione.
- **Contenuto:** 5 righe di rischio: custodia concentrata · dipendenza dall'operatore per la movimentazione · perimetro regolamentare che cresce con ogni servizio · superficie on-chain proprietaria da mantenere e auditare · onere di verifica (380 finding nel registro security).
- **Visual:** righe con token circolari numerati e chip di impatto; callout del registro finding.
- **Speaker notes:** Nessuno di questi punti è un difetto di codice: sono conseguenze del modello pooled. Aggiungere carte, IBAN e securities su questo modello significherebbe moltiplicare esattamente questi rischi.
- **Fonti:** brief §Obiettivo narrativo (riduzione superficie); §Accuratezza (380 finding).

### Slide 7 — Perché integrare
- **Obiettivo:** giustificare la scelta build-vs-integrate senza sovrapromettere.
- **Titolo:** *Integrare batte ricostruire: stesso perimetro funzionale, meno rischio proprietario*
- **Messaggio principale:** i provider mantengono le funzioni regolamentate; Jethos mantiene l'esperienza e l'integrità del piano.
- **Contenuto:** confronto in due colonne (Ricostruire internamente vs Integrare provider e protocolli) su 4 dimensioni: tempo, perimetro regolamentare, superficie custodiale, manutenzione; banda inferiore *"Cosa NON cambia"*: la responsabilità applicativa resta a Jethos.
- **Visual:** due colonne + banda di avvertenza in fondo.
- **Speaker notes:** Da dire esplicitamente: l'uso di provider non elimina né la sicurezza né la responsabilità di Jethos. Riduce i punti in cui Jethos può perdere o movimentare fondi.
- **Fonti:** brief §Obiettivo narrativo (elenco riduzioni e responsabilità residue).

### Slide 8 — Principi non negoziabili
- **Obiettivo:** fissare i vincoli che qualsiasi design successivo deve rispettare.
- **Titolo:** *Sei principi non negoziabili: l'utente decide, autorizza ed esegue*
- **Messaggio principale:** i confini sono espliciti e verificabili, non dichiarativi.
- **Contenuto:** 6 principi: (1) l'utente possiede e controlla lo Smart Account; (2) l'utente sceglie importi, protocolli, asset e limiti; (3) il client Jethos costruisce, decodifica, presenta e simula il piano; (4) l'utente autorizza l'esatto envelope eseguibile; (5) fondi e ordini vanno direttamente a Smart Account, provider o protocollo; (6) Jethos non custodisce fondi, non conserva chiavi utente, non firma per l'utente, non inoltra ordini finanziari firmati.
- **Visual:** slide dark, griglia 2×3 di card traslucide con numeri; badge `TARGET DECISION`.
- **Speaker notes:** Questi sei punti sono il test di accettazione di ogni feature futura. Se una feature viola uno di questi principi, non è una feature Jethos.
- **Fonti:** brief §Obiettivo narrativo (elenco confini).

### Slide 9 — Architettura target
- **Obiettivo:** mostrare il modello completo a tre bande con i flussi corretti.
- **Titolo:** *Architettura target: Jethos compila e spiega, l'utente autorizza ed esegue*
- **Messaggio principale:** i fondi non attraversano mai Jethos; passano solo piani, dati e decodifiche.
- **Contenuto:** banda User (Smart Account, chiavi, firma) · banda Jethos software (build, decode, preview, simulate, registry, UX aggregata — nessuna custodia, nessuna chiave) · banda Provider/Protocol (CDP, Sumsub, Monerium, Reap, 21X | Aave, Morpho Blue, MetaMorpho, Euler, DEX); frecce distinte per "piano/dati" e "fondi/ordini".
- **Visual:** diagramma a tre bande con legenda colori dei soggetti.
- **Speaker notes:** La linea continua rappresenta fondi e ordini: parte dall'utente e arriva al provider o al protocollo. La linea tratteggiata rappresenta piani e dati: è l'unica cosa che tocca Jethos.
- **Fonti:** brief §Obiettivo narrativo; §Struttura slide 9, 12, 13.

### Slide 10 — Lifecycle
- **Obiettivo:** rendere operativo il principio di controllo.
- **Titolo:** *Il controllo si esercita in otto passi, e la firma arriva solo alla fine*
- **Messaggio principale:** ogni operazione attraversa la stessa pipeline verificabile.
- **Contenuto:** configure → build → decode → preview → simulate → authorize → execute → verify, con l'indicazione del soggetto responsabile per ogni passo (User / Jethos / Provider-Protocol).
- **Visual:** 8 step in due file da 4, con codifica colore per soggetto; evidenza sul passo *authorize* come unico punto di firma.
- **Speaker notes:** Prima della firma l'utente ha già visto calldata decodificata, effetti simulati e limiti. Dopo la firma Jethos non ha più alcun ruolo attivo se non la verifica dell'esito.
- **Fonti:** brief §Struttura slide 10.

### Slide 11 — Smart Account ed exact executable-envelope
- **Obiettivo:** spiegare cosa esattamente l'utente firma.
- **Titolo:** *L'utente firma un envelope esatto, non una delega generica*
- **Messaggio principale:** l'envelope è vincolato a target, calldata, valore, limiti, chain e scadenza.
- **Contenuto:** card envelope con i campi (target, calldata decodificata, value, cap/limiti, chainId, nonce, scadenza) + colonna "cosa l'utente non firma mai" (deleghe aperte, approvazioni illimitate, ordini pre-firmati inoltrati da Jethos).
- **Visual:** card documento a sinistra, lista di esclusioni a destra. Nessun indirizzo reale, nessun secret: solo segnaposto.
- **Speaker notes:** L'envelope è il confine tecnico del principio "l'utente autorizza". Se il piano cambia dopo la preview, cambia l'envelope e serve una nuova firma.
- **Fonti:** brief §Obiettivo narrativo; §Requisiti visuali (nessuna credenziale o EOA completo).

### Slide 12 — Moduli esterni
- **Obiettivo:** distinguere ciò che è deciso da ciò che dipende da terzi.
- **Titolo:** *Cinque moduli esterni: la decisione è nostra, l'abilitazione no*
- **Messaggio principale:** ogni provider è una decisione target con un gate esterno ancora aperto.
- **Contenuto:** 5 card: Coinbase CDP (wallet/Smart Account) · Sumsub (identity/KYC) · Monerium (cash/IBAN/EURe) · Reap (card) · 21X (securities handoff). Per ciascuna: funzione target + `EXTERNAL GATE` con la domanda aperta (disponibilità, contratto, copertura geografica, requisiti di conformità).
- **Visual:** riga di 5 card verticali con doppio badge.
- **Speaker notes:** Nessuna capability di questi provider è confermata dalle fonti. In presentazione vanno trattate come external gate: sono la direzione scelta, non funzionalità disponibili.
- **Fonti:** brief §Gerarchia delle fonti punto 3; §Struttura slide 12.

### Slide 13 — Layer DeFi diretto
- **Obiettivo:** mostrare che la DeFi resta di primo livello ma cambia intestazione.
- **Titolo:** *La DeFi resta diretta: posizioni intestate all'utente, non al pool*
- **Messaggio principale:** chiamate dirette dallo Smart Account, senza quote intermedie.
- **Contenuto:** protocolli (Aave, Morpho Blue, MetaMorpho, Euler, DEX) con funzione sintetica; schema Smart Account → chiamata diretta → protocollo; confronto rapido con il modello LPT.
- **Visual:** lista protocolli a sinistra, mini-diagramma a destra; badge `TARGET DECISION`.
- **Speaker notes:** Differenza sostanziale: oggi l'utente ha una quota del pool; nel target ha una posizione a suo nome sul protocollo, verificabile on-chain indipendentemente da Jethos.
- **Fonti:** brief §Struttura slide 13; §Accuratezza (direct protocol calls).

### Slide 14 — Multi-chain
- **Obiettivo:** definire il modello multi-chain senza ambiguità.
- **Titolo:** *Multi-chain by design: account e indirizzi distinti per ogni chain*
- **Messaggio principale:** vista aggregata per l'utente, isolamento per chain nell'esecuzione.
- **Contenuto:** vista aggregata read-only in alto; 3 card chain (Arbitrum, Base, Polygon) con account e indirizzo distinti; gate aperto su bridging e movimenti cross-chain.
- **Visual:** banda aggregata + 3 card; badge `EXTERNAL GATE` sul bridging.
- **Speaker notes:** L'aggregazione è una funzione di lettura. L'esecuzione resta per chain, con account separati: questo evita ipotesi implicite di fungibilità tra reti.
- **Fonti:** brief §Struttura slide 14.

### Slide 15 — Preserve / Extract / Rewrite / Remove
- **Obiettivo:** dare la mappa operativa del refactor.
- **Titolo:** *Preserviamo il valore del client, rimuoviamo la custodia*
- **Messaggio principale:** quattro trattamenti distinti per i 56 componenti classificati.
- **Contenuto:** quadranti — PRESERVE (UX, decodifica, registry, simulazione) · EXTRACT (logiche riusabili dal protocollo verso il client) · REWRITE (esecuzione, autorizzazione, gestione posizioni) · REMOVE (custodia pooled, emissione LPT, movimentazione operatore).
- **Visual:** griglia 2×2 con codifica colore e conteggio "56 componenti classificati — ripartizione da confermare sul registro".
- **Speaker notes:** La ripartizione numerica per quadrante va letta dal registro dei 56 componenti prima della pubblicazione: qui indichiamo i criteri, non i conteggi.
- **Fonti:** brief §Accuratezza (56 componenti); §Struttura slide 15.

### Slide 16 — Migrazione del sistema legacy
- **Obiettivo:** mostrare che l'uscita dal legacy è governata da prove.
- **Titolo:** *Il legacy si chiude con prove, non con annunci*
- **Messaggio principale:** sei fasi sequenziali, ciascuna con un artefatto verificabile.
- **Contenuto:** snapshot → zero-loss fork proof → freeze autorizzato → exit → revoke → retire; nota critica: le osservazioni live a 3,1 USDC/LPT **non sono migration-grade** e devono essere ripetute.
- **Visual:** timeline a 6 step con marcatori; callout `SECURITY BLOCKER` sull'osservazione 3,1.
- **Speaker notes:** Il valore osservato 3,1 USDC/LPT è indicativo, non una base di migrazione. Serve una rilevazione ripetuta con criteri migration-grade prima di qualunque freeze.
- **Fonti:** brief §Accuratezza (3,1 USDC/LPT); §Struttura slide 16.

### Slide 17 — Sicurezza, privacy e confine regolamentare
- **Obiettivo:** evitare l'equivoco "provider = meno responsabilità".
- **Titolo:** *Meno custodia non significa meno sicurezza: cosa resta in capo a Jethos*
- **Messaggio principale:** esce il rischio custodiale, resta interamente il rischio applicativo.
- **Contenuto:** colonna "cosa esce dal perimetro" (custodia fondi, chiavi utente, funzioni regolamentate, stato delle posizioni) vs colonna "cosa resta a Jethos" (sicurezza applicativa, supply-chain, privacy, OAuth/webhook, protezione dei secret, transaction integrity, registry provenance, continuità operativa).
- **Visual:** due colonne bilanciate, la destra più densa; badge `SECURITY BLOCKER`.
- **Speaker notes:** La colonna di destra è più lunga della sinistra, ed è voluto: è il messaggio della slide.
- **Fonti:** brief §Obiettivo narrativo (elenco responsabilità residue).

### Slide 18 — Roadmap
- **Obiettivo:** sequenziare il lavoro per gate, non per date.
- **Titolo:** *Roadmap per milestone: ogni gate chiuso sblocca la milestone successiva*
- **Messaggio principale:** la sequenza è vincolata dalle dipendenze, non dal calendario.
- **Contenuto:** M0 chiusura gate architetturali → M1 Smart Account + envelope + lifecycle → M2 identity e cash → M3 card e investimenti → M4 DeFi diretta multi-chain → M5 retire del legacy; riga dipendenze principali sotto ogni milestone.
- **Visual:** timeline orizzontale a 6 nodi con riga di dipendenze; nessuna data promessa.
- **Speaker notes:** Le date non sono nelle fonti: qui sequenziamo per dipendenza. La prima milestone non produce funzionalità utente, produce decisioni chiuse.
- **Fonti:** brief §Struttura slide 18 (sequenza proposta come ipotesi).

### Slide 19 — Blocker e decisioni necessarie
- **Obiettivo:** trasformare NOT_READY in una lista azionabile.
- **Titolo:** *NOT_READY_FOR_IMPLEMENTATION: direzione valida, gate ancora aperti*
- **Messaggio principale:** quattro famiglie di gate: architetturale, sicurezza, stato legacy, provider.
- **Contenuto:** card di lettura del verdetto + tabella di 6 decisioni aperte con badge di tipo e criterio di chiusura (fra cui: rilevazioni migration-grade in sostituzione del 3,1 USDC/LPT; conferma capability provider; triage dei 380 finding; sequenziamento dei 278 task).
- **Visual:** callout a sinistra, righe decisione a destra.
- **Speaker notes:** Ripetere esplicitamente: NOT_READY non boccia la strategia. Significa che questi gate vanno chiusi prima dell'implementazione.
- **Fonti:** brief §Accuratezza; §"Non presentare NOT_READY come bocciatura".

### Slide 20 — End state
- **Obiettivo:** chiudere con la promessa verificabile.
- **Titolo:** *End state: un Financial OS che non tocca mai i fondi dell'utente*
- **Messaggio principale:** Jethos diventa software di orchestrazione e trasparenza; l'utente ottiene un'unica esperienza con proprietà reale.
- **Contenuto:** tre colonne — cosa diventa Jethos · cosa riceve l'utente · cosa Jethos non fa più; frase di chiusura con il principio.
- **Visual:** slide dark, tre colonne, principio in evidenza.
- **Speaker notes:** Chiusura: se un domani Jethos smettesse di operare, l'utente manterrebbe Smart Account, posizioni e rapporti con i provider. Questa è la definizione operativa di software-only.
- **Fonti:** brief §Obiettivo narrativo; §Struttura slide 20.

---

## APPENDICE (A1–A4)

### A1 — Classificazione quantitativa dei componenti
- **Obiettivo:** dare il dato che abilita il refactor.
- **Titolo:** *56 componenti classificati, 0 richiedono on-chain per il V1*
- **Messaggio principale:** il V1 è realizzabile interamente lato software.
- **Contenuto:** unit chart di 56 unità, 0 marcate ONCHAIN_REQUIRED; nota sulla ripartizione per trattamento da leggere sul registro.
- **Visual:** griglia 7×8 di quadrati + due stat callout.
- **Speaker notes:** È il numero più importante dell'audit: nessun componente V1 impone lavoro on-chain.
- **Fonti:** brief §Accuratezza.

### A2 — Matrice current vs target
- **Obiettivo:** riferimento sintetico per il team tecnico.
- **Titolo:** *Current vs target, dominio per dominio*
- **Contenuto:** righe: custodia, intestazione posizione, esecuzione, upgrade/lookup (Beacon service locator), identità, cash, carte, securities.
- **Visual:** tabella a 3 colonne con codifica colore.
- **Speaker notes:** Da usare come checklist di allineamento nelle review tecniche.
- **Fonti:** brief §Accuratezza; §Struttura appendice A2.

### A3 — External gate / provider matrix
- **Obiettivo:** rendere esplicito lo stato di ogni dipendenza esterna.
- **Titolo:** *Nessuna capability provider è confermata: cinque gate da chiudere*
- **Contenuto:** tabella provider | funzione target | stato | evidenza richiesta per chiudere il gate.
- **Visual:** tabella a 4 colonne con badge `EXTERNAL GATE` su ogni riga.
- **Speaker notes:** Questa slide protegge il team commerciale: nessuna di queste funzioni può essere annunciata come disponibile.
- **Fonti:** brief §Gerarchia delle fonti punto 3.

### A4 — Checklist e criteri di go/no-go
- **Obiettivo:** definire quando si passa a implementazione.
- **Titolo:** *Da NOT_READY a GO: cinque criteri di uscita*
- **Contenuto:** riferimenti 278 task / 380 finding; criteri: gate architetturali chiusi, finding critici risolti o accettati formalmente, stato legacy misurato con criteri migration-grade, capability provider confermate contrattualmente, envelope e lifecycle verificati end-to-end.
- **Visual:** due stat callout + 5 criteri in card numerate.
- **Speaker notes:** La checklist revisionata resta il riferimento operativo: non va trasformata integralmente in slide.
- **Fonti:** brief §Gerarchia delle fonti punto 4; §Accuratezza.
