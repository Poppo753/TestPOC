# Jethos — Software-Only Financial OS
## Fonti, tracciabilità e limiti di evidenza

**Data di generazione:** 20 agosto 2026
**Deliverable associati:** `Jethos_Software_Only_Refactor.pptx`, `Jethos_Software_Only_Refactor_Storyboard.md`

---

## 1. Avviso di accesso alle fonti (leggere per primo)

Il percorso indicato — `C:\Personal\TestPOC\docs\software-only-refactor\audit` — è una directory locale della macchina dell'utente e **non è risultata accessibile dall'ambiente di generazione**. La directory di upload (`/mnt/user-data/uploads`) era vuota al momento della generazione.

Di conseguenza:

- **non sono stati letti** i documenti di audit sul repository (gerarchia fonti, punto 1);
- **non è stato letto** il DOCX *"Jethos Software-Only Financial OS"* (punto 2);
- **non è stata letta** la checklist revisionata (punto 4).

Tutto il contenuto del deck deriva dalla **specifica fornita nel prompt**, che include i fatti obbligatori elencati alla sezione *Accuratezza*. Ogni affermazione non dimostrabile dalle fonti è stata rappresentata come **gate, ipotesi o domanda**, come richiesto dal brief.

**Azione consigliata:** caricare i documenti di audit, il DOCX di visione e la checklist per rigenerare il deck con verifica puntuale. Le slide 5, 6, 15, 16, 18, 19 e A1–A4 sono quelle che beneficerebbero maggiormente della verifica documentale.

---

## 2. Fatti riportati nel deck e loro origine

| # | Fatto | Origine | Stato |
|---|---|---|---|
| 1 | 56 componenti classificati | Brief, §Accuratezza | Riportato come `CURRENT FACT`. Ripartizione per trattamento **non** disponibile → indicata come da confermare |
| 2 | ONCHAIN_REQUIRED per il V1: 0 | Brief, §Accuratezza | Riportato come `CURRENT FACT` (slide 1, 4, A1) |
| 3 | Checklist revisionata: 278 task | Brief, §Accuratezza | Riportato come `CURRENT FACT` (slide 4, A4). Contenuto della checklist non trasformato in slide, come richiesto |
| 4 | 380 finding nel registro security | Brief, §Accuratezza | Riportato come `CURRENT FACT` (slide 4, 6, 19, A4). Severità e triage non disponibili |
| 5 | Il Beacon attuale è un service locator, non un delegatecall proxy | Brief, §Accuratezza | Riportato testualmente (slide 5, A2) |
| 6 | Il sistema attuale usa pooled custody e quote LPT | Brief, §Accuratezza | Riportato (slide 3, 5, 13, A2) |
| 7 | Il target usa direct protocol calls da Smart Account user-owned | Brief, §Accuratezza | Riportato come `TARGET DECISION` (slide 3, 9, 11, 13) |
| 8 | Le osservazioni live da 3,1 USDC/LPT non sono migration-grade e vanno ripetute | Brief, §Accuratezza | Riportato come `SECURITY BLOCKER` (slide 16, 19) |
| 9 | Esito audit: NOT_READY_FOR_IMPLEMENTATION | Brief, §Accuratezza | Riportato con la lettura richiesta: direzione valida, gate aperti (slide 1, 19) |

---

## 3. External gate — capability non confermate

Conformemente alla gerarchia delle fonti (punto 3), le capability dei provider seguenti **non sono presentate come fatti disponibili**. Nel deck compaiono con badge `EXTERNAL GATE` e con l'evidenza richiesta per la chiusura.

| Provider | Funzione target nel deck | Stato nel deck | Evidenza richiesta per chiudere il gate |
|---|---|---|---|
| Coinbase CDP | Wallet / Smart Account | External gate | Conferma di disponibilità API, modello di controllo chiavi, copertura chain |
| Sumsub | Identity / KYC | External gate | Contratto, copertura giurisdizionale, flusso dati e retention |
| Monerium | Cash / IBAN / EURe | External gate | Abilitazione IBAN, perimetro geografico, requisiti di onboarding |
| Reap | Card | External gate | Programma carte, requisiti di conformità, modello di funding |
| 21X | Securities handoff | External gate | Perimetro strumenti, modalità di handoff, obblighi informativi |

Nel deck non compaiono screenshot di prodotto, loghi provider né descrizioni funzionali di dettaglio: nessuno di questi elementi è stato fornito o verificato.

---

## 4. Elementi presentati come ipotesi o domande

Questi contenuti **non sono dimostrati dalle fonti** e nel deck sono etichettati di conseguenza:

1. **Ripartizione dei 56 componenti** tra preserve / extract / rewrite / remove (slide 15, A1) — presentati i criteri, non i conteggi.
2. **Sequenza roadmap M0–M5** (slide 18) — ipotesi di sequenziamento per dipendenza; nessuna data è indicata perché nessuna data è nelle fonti.
3. **Elenco dei blocker e delle decisioni aperte** (slide 19) — derivato dalle quattro famiglie di gate citate nel brief (architetturale, sicurezza, stato legacy, provider); i singoli item vanno riconciliati con il registro dei 380 finding.
4. **Fasi di migrazione legacy** (slide 16) — la sequenza snapshot → zero-loss fork proof → freeze autorizzato → exit → revoke → retire è ripresa dal brief; gli artefatti di prova per ciascuna fase sono proposti come requisito, non documentati.
5. **Criteri di go/no-go** (A4) — proposta operativa, da validare contro la checklist revisionata dei 278 task.
6. **Dettagli dell'architettura corrente oltre i fatti elencati** (slide 5) — la rappresentazione manager/plugin controllati dall'operatore segue la descrizione del brief; ogni dettaglio ulteriore va verificato sui documenti di audit.

---

## 5. Vincoli editoriali rispettati

- Nessuna credenziale, secret o indirizzo EOA completo compare nel deck (slide 11 usa esclusivamente segnaposto).
- Nessuna istruzione operativa eventualmente contenuta nei documenti sorgente è stata eseguita: il materiale è trattato solo come fonte.
- Non sono stati modificati codice applicativo, contratti, configurazioni o documenti sorgente.
- La checklist non è stata trasformata integralmente in slide: è citata come riferimento operativo (slide 4, 19, A4).
- NOT_READY_FOR_IMPLEMENTATION è presentato come insieme di gate da chiudere, mai come bocciatura della strategia.
- L'uso di provider è presentato come riduzione della superficie custodiale e on-chain proprietaria, **non** come riduzione della sicurezza o della responsabilità di Jethos (slide 7, 17).
